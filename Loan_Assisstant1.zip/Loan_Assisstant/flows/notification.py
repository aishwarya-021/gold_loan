import csv
import os
import hashlib

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")

NOTIFY_FILE = os.path.join(DATA_DIR, "notifications.csv")
DECISION_FILE = os.path.join(DATA_DIR, "decisions", "decision_logs.csv")

# --------------------------------------------------
# INTERNAL API KEY VALIDATION (session-level)
# --------------------------------------------------
def validate_api_key(api_key: str) -> bool:
    return api_key is not None and len(api_key) >= 10


# --------------------------------------------------
# LOAD CSV SAFELY
# --------------------------------------------------
def load_csv(path):
    if not os.path.exists(path):
        return []
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


# --------------------------------------------------
# PUBLIC API: FETCH CUSTOMER NOTIFICATIONS
# --------------------------------------------------
def fetch_customer_notifications(customer_id: str, api_key: str):
    if not validate_api_key(api_key):
        return []

    return [
        n for n in load_csv(NOTIFY_FILE)
        if n["customer_id"] == customer_id
    ]


# --------------------------------------------------
# PUBLIC API: UNREAD COUNT (for badge)
# --------------------------------------------------
def fetch_unread_count(customer_id: str, api_key: str) -> int:
    if not validate_api_key(api_key):
        return 0

    return sum(
        1 for n in load_csv(NOTIFY_FILE)
        if n["customer_id"] == customer_id and n["read_status"] == "UNREAD"
    )


# --------------------------------------------------
# PUBLIC API: APPLICATION TIMELINE (Officer + BM)
# --------------------------------------------------
def fetch_application_timeline(application_id: str, api_key: str):
    if not validate_api_key(api_key):
        return []

    timeline = [
        d for d in load_csv(DECISION_FILE)
        if d["application_id"] == application_id
    ]

    return sorted(timeline, key=lambda x: x["timestamp"])
