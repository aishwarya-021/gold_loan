import streamlit as st
import os
import csv

# ==================================================
# PAGE CONFIG (MUST BE FIRST)
# ==================================================
st.set_page_config(
    page_title="Gold Loan Assistant",
    layout="wide"
)

# ==================================================
# PROJECT ROOT SAFETY
# ==================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE_DIR)

DATA_DIR = os.path.join(BASE_DIR, "data")
NOTIFY_FILE = os.path.join(DATA_DIR, "notifications.csv")

# ==================================================
# GLOBAL SESSION STATE INIT (CRITICAL)
# ==================================================
st.session_state.setdefault("bm_logged_in", False)
st.session_state.setdefault("bm_user", None)

st.session_state.setdefault("logged_officer", False)
st.session_state.setdefault("officer_name", None)

st.session_state.setdefault("logged_customer", False)
st.session_state.setdefault("customer_id", None)

# ==================================================
# SAFE IMPORTS
# ==================================================
customer_error = officer_error = bm_error = None

try:
    from flows.customer_flow import render_customer_flow
except Exception as e:
    render_customer_flow = None
    customer_error = e

try:
    from flows.officer_flow import render_officer_flow
except Exception as e:
    render_officer_flow = None
    officer_error = e

try:
    from flows.branch_manager import render_branch_manager_flow
except Exception as e:
    render_branch_manager_flow = None
    bm_error = e

# ==================================================
# NOTIFICATION COUNT (UNREAD)
# ==================================================
def get_unread_notification_count(customer_id):
    if not customer_id or not os.path.exists(NOTIFY_FILE):
        return 0

    count = 0
    with open(NOTIFY_FILE, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            if (
                r.get("customer_id") == customer_id
                and r.get("read_status", "").upper() == "UNREAD"
            ):
                count += 1
    return count

# ==================================================
# APP HEADER
# ==================================================
st.title("🏦 Gold Loan Assistant")
st.caption("Customer • Loan Officer • Branch Manager Workflow")

# ==================================================
# SIDEBAR NAVIGATION (ROLE AWARE)
# ==================================================
st.sidebar.title("Navigation")

# -------- CUSTOMER LOGGED IN --------
if st.session_state.logged_customer:
    unread = get_unread_notification_count(st.session_state.customer_id)
    badge = f" 🔔 {unread}" if unread else ""

    portal = st.sidebar.radio(
        "Customer Portal",
        [f"Customer{badge}"]
    )

# -------- OFFICER LOGGED IN --------
elif st.session_state.logged_officer:
    portal = st.sidebar.radio(
        "Select Portal",
        ["Customer", "Loan Officer"]
    )

# -------- BM LOGGED IN --------
elif st.session_state.bm_logged_in:
    portal = st.sidebar.radio(
        "Select Portal",
        ["Customer", "Branch Manager"]
    )

# -------- NOT LOGGED IN --------
else:
    portal = st.sidebar.radio(
        "Select Portal",
        ["Customer", "Loan Officer", "Branch Manager"]
    )

st.sidebar.divider()

# ==================================================
# ROUTING
# ==================================================
if portal.startswith("Customer"):

    st.subheader("👤 Customer Portal")

    if render_customer_flow is None:
        st.error("❌ Customer module failed to load")
        st.exception(customer_error)
    else:
        render_customer_flow()

elif portal == "Loan Officer":

    st.subheader("🧑‍💼 Loan Officer Portal")

    if render_officer_flow is None:
        st.error("❌ Officer module failed to load")
        st.exception(officer_error)
    else:
        render_officer_flow()

else:  # Branch Manager

    st.subheader("🏦 Branch Manager Portal")

    if render_branch_manager_flow is None:
        st.error("❌ Branch Manager module failed to load")
        st.exception(bm_error)
    else:
        render_branch_manager_flow()

# ==================================================
# FOOTER
# ==================================================
st.sidebar.markdown("---")
st.sidebar.caption("Gold Loan Assistant • Streamlit Application")
