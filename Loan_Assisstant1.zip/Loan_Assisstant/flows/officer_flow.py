import streamlit as st
import csv
import os
import re
import math
import hashlib
from datetime import datetime, date, time
from collections import Counter
from PyPDF2 import PdfReader

# =========================================================
# PATHS
# =========================================================
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")

APP_FILE = os.path.join(DATA_DIR, "applications.csv")
CUSTOMER_FILE = os.path.join(DATA_DIR, "customers.csv")
OFFICER_FILE = os.path.join(DATA_DIR, "loan_officers.csv")
POLICY_DIR = DATA_DIR

DECISION_FILE = os.path.join(DATA_DIR, "decisions", "decision_logs.csv")
ESCALATION_FILE = os.path.join(DATA_DIR, "escalations.csv")
VISIT_FILE = os.path.join(DATA_DIR, "branch_visits.csv")
NOTIFY_FILE = os.path.join(DATA_DIR, "notifications.csv")

os.makedirs(os.path.dirname(DECISION_FILE), exist_ok=True)

# =========================================================
# EMBEDDING
# =========================================================
def embed(text):
    return Counter(re.findall(r"\w+", text.lower()))

def cosine(a, b):
    common = set(a) & set(b)
    num = sum(a[x] * b[x] for x in common)
    den = math.sqrt(sum(v*v for v in a.values())) * math.sqrt(sum(v*v for v in b.values()))
    return num / den if den else 0.0

# =========================================================
# POLICY LOADING
# =========================================================
def clean_policy_sentences(text):
    lines = [l.strip() for l in text.split("\n") if l.strip()]
    sentences, buf = [], ""
    for l in lines:
        buf += " " + l
        if len(buf.split()) >= 10:
            sentences.append(buf.strip())
            buf = ""
    return sentences

def load_policies():
    policies = []
    pdfs = [f for f in os.listdir(POLICY_DIR) if f.lower().endswith(".pdf")]
    if not pdfs:
        return [], True

    for f in pdfs:
        reader = PdfReader(os.path.join(POLICY_DIR, f))
        full = " ".join(p.extract_text() or "" for p in reader.pages)
        parts = re.split(r"\n\s*(\d+)\.\s+", full)
        for i in range(1, len(parts), 2):
            policies.append({
                "policy": f,
                "clause": f"§{parts[i]}",
                "sentences": clean_policy_sentences(parts[i+1]),
                "embedding": embed(parts[i+1])
            })
    return policies, False

POLICIES, POLICY_PDF_MISSING = load_policies()

# =========================================================
# AGENTS
# =========================================================
def document_validation_agent(app):
    required = ["Requested_Amount", "Net_Weight", "Carat", "Tenure"]
    return [r for r in required if not app.get(r)]

def risk_evaluation_agent(app):
    amt = float(app["Requested_Amount"])
    if amt > 500000:
        return "HIGH"
    elif amt > 200000:
        return "MEDIUM"
    return "LOW"

def policy_alignment_agent(app):
    query = f"gold loan {app['Requested_Amount']} {app['Tenure']} {app['Carat']} ltv"
    if not POLICIES:
        return query, [], True

    qemb = embed(query)
    scored = [(round(cosine(qemb, p["embedding"]), 2), p) for p in POLICIES]
    scored.sort(key=lambda x: x[0], reverse=True)

    if not scored or scored[0][0] == 0:
        return query, [], True

    return query, scored[:3], False

def confidence_score(policy_score, risk, missing):
    score = 0.4 if not missing else 0
    score += policy_score * 0.4
    score += 0.2 if risk == "LOW" else 0.1 if risk == "MEDIUM" else 0
    return round(min(score, 1.0), 2)

# =========================================================
# CSV HELPERS
# =========================================================
def append_csv(path, header, row):
    exists = os.path.exists(path)
    with open(path, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        if not exists:
            writer.writerow(header)
        writer.writerow(row)

def load_decisions_for_app(app_id):
    if not os.path.exists(DECISION_FILE):
        return []
    with open(DECISION_FILE, newline="", encoding="utf-8") as f:
        return [d for d in csv.DictReader(f) if d["application_id"] == app_id]

def fetch_customer_details(customer_id):
    if not os.path.exists(CUSTOMER_FILE):
        return {}
    with open(CUSTOMER_FILE, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            if r["Customer_ID"] == customer_id:
                return {k: v for k, v in r.items() if k.upper() != "PIN"}
    return {}

# =========================================================
# OFFICER FLOW
# =========================================================
def render_officer_flow():

    st.session_state.setdefault("logged_officer", False)
    st.session_state.setdefault("evaluated_app", None)

    # ---------------- LOGIN ----------------
    if not st.session_state.logged_officer:
        st.subheader("🔐 Loan Officer Login")
        emp = st.text_input("Employee Code")
        pin = st.text_input("PIN", type="password")

        if st.button("Login"):
            with open(OFFICER_FILE, newline="", encoding="utf-8") as f:
                for r in csv.DictReader(f):
                    if r["EmpCode"] == emp and r["PIN"] == pin:
                        st.session_state.logged_officer = True
                        st.session_state.officer_id = emp
                        st.session_state.officer_name = r["Name"]
                        st.rerun()
        return

    # ---------------- APPLICATION LIST ----------------
    with open(APP_FILE, newline="", encoding="utf-8") as f:
        apps = list(csv.DictReader(f))

    st.subheader("📂 Applications")
    for i, a in enumerate(apps):
        if st.button(f"Evaluate {a['Application_ID']}", key=i):
            st.session_state.evaluated_app = a
            st.rerun()

    if not st.session_state.evaluated_app:
        return

    app = st.session_state.evaluated_app

    # ---------------- AGENT RUN ----------------
    missing = document_validation_agent(app)
    risk = risk_evaluation_agent(app)
    query, policy_hits, policy_missing = policy_alignment_agent(app)

    policy_score = policy_hits[0][0] if policy_hits else 0.30
    conf = confidence_score(policy_score, risk, missing)

    # ---------------- RESULTS ----------------
    st.markdown("## 🧠 Agent Results")
    st.info(f"Risk Level: {risk}")
    st.info(f"Policy Score: {policy_score}")
    st.success(f"Confidence: {conf*100:.0f}%")

    if POLICY_PDF_MISSING:
        st.error("⚠️ Policy PDF missing")
    if policy_missing:
        st.warning("⚠️ Policy Missing Risk Flag applied")

    # ---------------- CUSTOMER DETAILS ----------------
    st.markdown("## 👤 Customer Details")
    customer = fetch_customer_details(app["Customer_ID"])
    for k, v in customer.items():
        st.write(f"**{k.replace('_',' ')}:** {v}")

    # ---------------- COMPARISON ----------------
    st.markdown("## 📊 Application vs Policy Comparison")
    st.table([
        {"Parameter": "Requested Amount", "Application": app["Requested_Amount"], "Policy": "Within LTV"},
        {"Parameter": "Gold Weight", "Application": app["Net_Weight"], "Policy": "Verified"},
        {"Parameter": "Gold Purity", "Application": app["Carat"], "Policy": "18K–24K"},
        {"Parameter": "Tenure", "Application": app["Tenure"], "Policy": "Allowed"},
        {"Parameter": "Risk", "Application": risk, "Policy": "Escalate if HIGH"}
    ])

    # ---------------- VISIT SLOT ----------------
    if risk != "HIGH":
        st.markdown("## 🏦 Schedule Branch Visit")
        with st.form("visit"):
            branch = st.selectbox("Branch", ["Mumbai Main Branch", "Delhi Central Branch", "Bengaluru City Branch"])
            v_date = st.date_input("Visit Date", min_value=date.today())
            v_time = st.time_input("Visit Time", value=time(11, 0))
            submit = st.form_submit_button("Confirm")

        if submit:
            append_csv(
                VISIT_FILE,
                ["application_id","branch","visit_date","visit_time","status","created_at"],
                [app["Application_ID"], branch, v_date.isoformat(), v_time.strftime("%H:%M"), "SCHEDULED", datetime.now().isoformat()]
            )
            st.success("✅ Branch visit scheduled")

    # ---------------- OFFICER DECISION ----------------
    st.markdown("## 📝 Officer Decision")
    decision = st.radio("Decision", ["Accept", "Reject", "Escalate to Branch Manager"])

    reason = ""
    if decision == "Reject":
        reason = st.selectbox(
            "Reason for Rejection",
            [
                "Document mismatch",
                "Gold purity issue",
                "Gold weight discrepancy",
                "Policy LTV breach",
                "High risk – not eligible"
            ]
        )

    remarks = st.text_area("Remarks (mandatory)")

    if st.button("Submit Decision"):
        if not remarks.strip():
            st.error("Remarks required")
            return

        route_to = "BRANCH_MANAGER" if decision == "Escalate to Branch Manager" else ""

        append_csv(
            DECISION_FILE,
            ["application_id","decision","actor_role","actor_id","risk_level","route_to","policy_missing","policy_score","remarks","timestamp"],
            [
                app["Application_ID"],
                decision.upper().replace(" ", "_"),
                "LOAN_OFFICER",
                st.session_state.officer_id,
                risk,
                route_to,
                "YES" if policy_missing else "NO",
                policy_score,
                f"{reason} | {remarks}" if reason else remarks,
                datetime.now().isoformat()
            ]
        )

        if decision == "Escalate to Branch Manager":
            payload = f"{app['Application_ID']}|{st.session_state.officer_id}|{risk}|{policy_score}|{remarks}"
            checksum = hashlib.sha256(payload.encode()).hexdigest()

            append_csv(
                ESCALATION_FILE,
                ["application_id","officer_id","risk_level","policy_missing","policy_score","remarks","status","created_at","checksum"],
                [app["Application_ID"], st.session_state.officer_id, risk, "YES" if policy_missing else "NO",
                 policy_score, remarks, "PENDING", datetime.now().isoformat(), checksum]
            )

        append_csv(
            NOTIFY_FILE,
            ["customer_id","application_id","message","created_at","read_status"],
            [app["Customer_ID"], app["Application_ID"],
             f"Your loan application has been {decision.lower()}.",
             datetime.now().isoformat(), "UNREAD"]
        )

        st.success("Decision recorded successfully.")
        st.session_state.evaluated_app = None
        st.rerun()

    # ---------------- TIMELINE ----------------
    st.markdown("## 🕒 Application Timeline")
    timeline = load_decisions_for_app(app["Application_ID"])

    if not timeline:
        st.info("No decisions recorded yet.")
    else:
        for t in sorted(timeline, key=lambda x: x["timestamp"]):
            st.write(
                f"🧾 **{t['decision']}** | "
                f"{t['actor_role']} `{t['actor_id']}` | "
                f"Risk `{t['risk_level']}` | "
                f"{t['timestamp']}"
            )
