import streamlit as st
import csv
import os
import hashlib
from datetime import datetime
from collections import Counter

# ==================================================
# PATHS
# ==================================================
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")

ESCALATION_FILE = os.path.join(DATA_DIR, "escalations.csv")
DECISION_FILE = os.path.join(DATA_DIR, "decisions", "decision_logs.csv")
BM_FILE = os.path.join(DATA_DIR, "users", "branch_managers.csv")

os.makedirs(os.path.dirname(DECISION_FILE), exist_ok=True)
os.makedirs(os.path.dirname(BM_FILE), exist_ok=True)

# ==================================================
# SESSION STATE
# ==================================================
st.session_state.setdefault("bm_logged_in", False)
st.session_state.setdefault("bm_user", None)

# ==================================================
# UTILITIES
# ==================================================
def load_csv(path):
    try:
        with open(path, newline="", encoding="utf-8") as f:
            return list(csv.DictReader(f))
    except FileNotFoundError:
        return []

def compute_checksum(row: dict) -> str:
    payload = (
        f"{row['application_id']}|{row['officer_id']}|"
        f"{row['risk_level']}|{row['policy_score']}|{row['remarks']}"
    )
    return hashlib.sha256(payload.encode()).hexdigest()

def verify_checksum(row):
    return compute_checksum(row) == row.get("checksum", "")

def append_decision_log(row: dict):
    exists = os.path.exists(DECISION_FILE)
    with open(DECISION_FILE, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "application_id",
                "decision",
                "actor_role",
                "actor_id",
                "risk_level",
                "route_to",
                "policy_missing",
                "policy_score",
                "remarks",
                "timestamp"
            ]
        )
        if not exists:
            writer.writeheader()
        writer.writerow(row)

def save_escalations(rows):
    if not rows:
        return
    with open(ESCALATION_FILE, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

def load_timeline(app_id):
    if not os.path.exists(DECISION_FILE):
        return []
    with open(DECISION_FILE, newline="", encoding="utf-8") as f:
        return [d for d in csv.DictReader(f) if d["application_id"] == app_id]

# ==================================================
# AUTH
# ==================================================
def authenticate_bm(bm_id, password):
    for u in load_csv(BM_FILE):
        if u["bm_id"] == bm_id and u["password"] == password:
            return u
    return None

def branch_manager_login():
    st.title("🔐 Branch Manager Login")

    with st.form("bm_login"):
        bm_id = st.text_input("Branch Manager ID")
        password = st.text_input("Password", type="password")
        submit = st.form_submit_button("Login")

    if submit:
        bm = authenticate_bm(bm_id, password)
        if bm:
            st.session_state.bm_logged_in = True
            st.session_state.bm_user = bm
            st.success("Login successful")
            st.rerun()
        else:
            st.error("Invalid credentials")

# ==================================================
# DASHBOARD
# ==================================================
def branch_manager_dashboard():
    st.title("🏦 Branch Manager – Escalated Loan Review")
    st.caption("Exception Handling | Human-in-the-Loop | Governance")

    escalations = load_csv(ESCALATION_FILE)
    pending = [e for e in escalations if e["status"] == "PENDING"]

    if not pending:
        st.success("No escalated cases pending review.")
        audit_view()
        return

    # ---------------- SUMMARY ----------------
    st.subheader("📊 Escalation Summary")
    col1, col2 = st.columns(2)
    col1.metric("Pending Escalations", len(pending))
    col2.metric(
        "Policy Missing Cases",
        sum(1 for e in pending if e["policy_missing"] == "YES")
    )

    # ---------------- SELECT CASE ----------------
    app_id = st.selectbox(
        "Select Application ID",
        sorted(set(e["application_id"] for e in pending))
    )

    case = next(e for e in pending if e["application_id"] == app_id)

    st.divider()

    # ---------------- DETAILS ----------------
    st.subheader("📂 Escalation Details")
    st.write(f"**Officer ID:** {case['officer_id']}")
    st.write(f"**Risk Level:** {case['risk_level']}")
    st.write(f"**Policy Missing:** {case['policy_missing']}")
    st.write(f"**Policy Score:** {case['policy_score']}")
    st.write(f"**Officer Remarks:** {case['remarks']}")

    # ---------------- CHECKSUM ----------------
    st.divider()
    st.subheader("🔐 Integrity Check")

    if verify_checksum(case):
        st.success("Checksum verified — escalation data is intact.")
    else:
        st.error("Checksum mismatch — possible data tampering detected!")

    # ---------------- TIMELINE ----------------
    st.divider()
    st.subheader("🕒 Application Timeline")

    timeline = load_timeline(app_id)
    timeline = sorted(timeline, key=lambda x: x["timestamp"])

    for t in timeline:
        st.write(
            f"🧾 **{t['decision']}** | "
            f"{t['actor_role']} `{t['actor_id']}` | "
            f"Time: {t['timestamp']}"
        )

    # ---------------- BM DECISION ----------------
    st.divider()
    st.subheader("🧑‍⚖️ Branch Manager Decision")

    decision = st.radio(
        "Decision",
        ["Approve Escalation", "Send Back to Loan Officer"]
    )

    bm_remarks = st.text_area("Mandatory BM Remarks")

    if st.button("Submit BM Decision"):
        if not bm_remarks.strip():
            st.error("Remarks are mandatory.")
            return

        new_status = "BM_APPROVED" if decision == "Approve Escalation" else "SENT_BACK"

        for e in escalations:
            if e["application_id"] == app_id and e["status"] == "PENDING":
                e["status"] = new_status
                e["checksum"] = compute_checksum(e)

        save_escalations(escalations)

        append_decision_log({
            "application_id": app_id,
            "decision": new_status,
            "actor_role": "BRANCH_MANAGER",
            "actor_id": st.session_state.bm_user["bm_id"],
            "risk_level": case["risk_level"],
            "route_to": "CLOSED" if new_status == "BM_APPROVED" else "LOAN_OFFICER",
            "policy_missing": case["policy_missing"],
            "policy_score": case["policy_score"],
            "remarks": bm_remarks,
            "timestamp": datetime.now().isoformat()
        })

        st.success("BM decision recorded successfully.")
        st.rerun()

    st.divider()
    audit_view()

# ==================================================
# AUDIT VIEW
# ==================================================
def audit_view():
    st.subheader("🛡 Audit & Monitoring")

    decisions = load_csv(DECISION_FILE)
    if not decisions:
        st.info("No audit records available.")
        return

    col1, col2, col3 = st.columns(3)
    col1.metric("Total Decisions", len(decisions))
    col2.metric("Officer Decisions", sum(1 for d in decisions if d["actor_role"] == "LOAN_OFFICER"))
    col3.metric("BM Decisions", sum(1 for d in decisions if d["actor_role"] == "BRANCH_MANAGER"))

    st.bar_chart(Counter(d["decision"] for d in decisions))

# ==================================================
# ENTRY POINT
# ==================================================
def render_branch_manager_flow():
    if not st.session_state.bm_logged_in:
        branch_manager_login()
    else:
        branch_manager_dashboard()
